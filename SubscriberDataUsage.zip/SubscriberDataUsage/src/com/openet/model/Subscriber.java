package com.openet.model;

import org.codehaus.jackson.annotate.JsonProperty;

public class Subscriber {
     
        private int Id;
	private int subscriberId;
	private int amount;
	private String timestamp;
        
        
        public int getId() 
	{
		return Id;
	}

	public void setId(int id) 
	{
		Id = id;
	}
	
	public int getAmount() 
	{
		return amount;
	}

	public void setAmount(int amount) 
	{
		this.amount = amount;
	}
	
	public String getTimestamp() 
	{
		return timestamp;
	}

	public void setTimestamp(String timestamp) 
	{
		this.timestamp = timestamp;
	}
        
	@JsonProperty(value = "subscriberId")
	public int getSubscriberId() {
		return subscriberId;
	}
	
	public void setSubscriberId(int customerId) {
		this.subscriberId = customerId;
	}
	

	@Override
	public String toString() {
		return "Subcriber [customerId=" + subscriberId + ", id=" + Id + ", amount=" + amount + ", timestamp=" + timestamp
				 + "]";
	}
	
        public Subscriber(int subscriberId, int amount, String timestamp) 
	{
		this.subscriberId = subscriberId;
		this.amount = amount;
		this.timestamp = timestamp;
	}

	public Subscriber() 
	{
	}
	
}
