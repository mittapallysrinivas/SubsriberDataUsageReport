package com.openet.service;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;
import org.codehaus.jackson.JsonGenerationException;
import org.codehaus.jackson.map.JsonMappingException;

import com.openet.dao.SubscriberDAO;
import com.openet.dao.impl.SubscriberDAOImpl;
import com.openet.model.Subscriber;

@Path("DataUsageService")
public class DataUsageService {
	private Logger logger = Logger.getLogger(DataUsageService.class);	

	@POST
	@Path("/reportSusbcriberDataUsage")
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response reportDataUsage(Subscriber susbcriberUsage) {
          if (susbcriberUsage == null)
		{
			logger.info("Input parameters not provided in reportUsage request.");
			return Response.noContent().build();
			
		}		
		else 
		{
			if(susbcriberUsage.getSubscriberId() == 0 || susbcriberUsage.getAmount() == 0 || 
					susbcriberUsage.getTimestamp()== null)
			{
				logger.info("Provide valid input parameters in reportUsage request. " +
						"subscriberId, amount should be greater than zero and " +
						"timestamp should not be null.");
				return Response.noContent().build();
                         
			}
		}
		SubscriberDAO daoImpl = new SubscriberDAOImpl();
		logger.info("Inside reportDataUsage...");
		
		Response resp = daoImpl.reportDataUsage(susbcriberUsage);
		return resp;
	}
	
	
	
	
	
	@POST
	@Path("/getAggregatedUsage")
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAggregatedUsage(@DefaultValue("0") @QueryParam("subscriberId") int subscriberId) throws JsonGenerationException,
		JsonMappingException, IOException {
                System.out.println("Inside getAggregatedUsage...");
		SubscriberDAO daoImpl = new SubscriberDAOImpl();
		logger.info("Inside getAggregatedUsage...");
		Response resp = daoImpl.getSubscriberAggregatedUsage(subscriberId);
		
		return resp;
	}
        
        
        @Path("/version")
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response getVersion() {
		logger.info("Inside getVersion()...");
                System.out.println("iam in safer postion..");
                return Response.ok("</HTML> <h1> <b> API_VERSION_1.2 </b><h1></HTML> ").build();
	
	}
	
}
