package com.openet.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.log4j.Logger;

import com.openet.dao.SubscriberDAO;
import com.openet.model.Subscriber;
import com.openet.model.StatusMessage;
import com.openet.util.Database;

public class SubscriberDAOImpl implements SubscriberDAO {
	private DataSource datasource = Database.getDataSource();
	private Logger logger = Logger.getLogger(SubscriberDAOImpl.class);
	
	@Override
	public Response reportDataUsage(Subscriber customer) {
		Connection conn = null;
    PreparedStatement ps = null;
    Statement stmt = null;
    ResultSet rs = null;
    StatusMessage statusMessage = null;
    int autoID = -1;
		
		String sql = "insert into susbcriberusage (customer_id, id, amount, timestamp) values (?,?,?,?)";
		
		try {
			conn = datasource.getConnection();
			ps = conn.prepareStatement(sql);
                        java.sql.Timestamp timestamp = java.sql.Timestamp.valueOf(customer.getTimestamp());                       	
			ps.setInt(1, customer.getSubscriberId());
			ps.setInt(2, customer.getId());
			ps.setInt(3, customer.getAmount());
			ps.setTimestamp(4, timestamp);
			
			
      int rows = ps.executeUpdate();
      
      if (rows == 0) {
  			logger.error("Unable to reportDataUsage for subscriber...");
  			statusMessage = new StatusMessage();
  			statusMessage.setStatus(Status.NOT_FOUND.getStatusCode());
  			statusMessage.setMessage("Unable to reportDataUsage for subscriber..");
  			return Response.status(404).entity(statusMessage).build();
      }
      
      stmt = conn.createStatement();
      rs = stmt.executeQuery("select LAST_INSERT_ID()");

      if (rs.next()) {
          autoID = rs.getInt(1);
          customer.setId(autoID);
      }
    
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					logger.error("Error closing resultset: " + e.getMessage());
					e.printStackTrace();
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					logger.error("Error closing PreparedStatement: " + e.getMessage());
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("Error closing connection: " + e.getMessage());
					e.printStackTrace();
				}
			}
		} 
		  return Response.ok("Success").build();
	}

	

	@Override
	public Response getSubscriberAggregatedUsage(int subscriberId) {
		Connection conn = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    
		List<Subscriber> susbcriberUsagebyDay = new ArrayList<Subscriber>();
		String sql = "select  cast(timestamp as date) as day, sum(amount) as totalusage from subscriberUsage WHERE customer_id = ? group by cast(timestamp as date)";
		
		try {
			conn = datasource.getConnection();
			ps = conn.prepareStatement(sql);
                        ps.setInt(1, subscriberId);
                        rs = ps.executeQuery();
      
      while (rs.next()) {
      	Subscriber cust = new Subscriber();
        if (rs.getInt("totalusage") > 0) {
      	   cust.setSubscriberId(rs.getInt("day"));
           cust.setAmount(rs.getInt("totalusage"));
      	   susbcriberUsagebyDay.add(cust);
        }
      }
      
      if (susbcriberUsagebyDay.isEmpty()) {
                 	logger.info(String.format("Subscriber has no Usage", subscriberId));
  		
      }
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					logger.error("Error closing resultset: " + e.getMessage());
					e.printStackTrace();
				}
			}
			if (ps != null) {
				try {
					ps.close();
				} catch (SQLException e) {
					logger.error("Error closing PreparedStatement: " + e.getMessage());
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					logger.error("Error closing connection: " + e.getMessage());
					e.printStackTrace();
				}
			}
		}
		return Response.status(200).entity(susbcriberUsagebyDay).build();
	}
}
