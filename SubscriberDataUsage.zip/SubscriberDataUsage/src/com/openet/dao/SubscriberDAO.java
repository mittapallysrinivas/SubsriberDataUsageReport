package com.openet.dao;

import javax.ws.rs.core.Response;

import com.openet.model.Subscriber;

public interface SubscriberDAO {
	
	public Response reportDataUsage(Subscriber dataUsage);
	public Response getSubscriberAggregatedUsage(int id);
	
}
